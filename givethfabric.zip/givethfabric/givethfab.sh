cd ~/givethfabric
export COMPOSER_CARD=admin@givethfabric
#export COMPOSER_TLS=true
#export COMPOSER_TLS_CERTIFICATE=/home/bnet/svrcert/vote.crt
#export COMPOSER_TLS_KEY=/home/bnet/svrcert/private.key
#export COMPOSER_NAMESPACES=never
#composer-rest-server -c admin@bnetvote
export COMPOSER_WEBSOCKETS=true
export COMPOSER_AUTHENTICATION=true
export COMPOSER_MULTIUSER=true
export COMPOSER_PROVIDERS='{
  "jwt": {
    "provider": "jwt",
    "module": "/home/b/givethfabric/node_modules/custom-jwt.js",
    "secretOrKey": "lkjldsfJHIWURsddfjhjllOIOImmnnbUIIUYkjhjawqwe",
    "authScheme": "saml",
    "successRedirect": "/",
    "failureRedirect":"/"
    }
}'
export COMPOSER_DATASOURCES='{
  "db": {
    "name": "db",
    "connector": "mongodb",
    "host": "localhost",
    "database": "gauth",
    "username": "admin",
    "password": "ad12345"
  }
}'
composer-rest-server -c admin@givethfabric -p 4000 -u true -a true -m true
