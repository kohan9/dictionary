/*
 * Created by @Khanh.
 * Sep15, 2019.
 */
const mongoose = require('mongoose')
//Kết nối CSDL MongoDB
const connectDatabase = async () => {
    try {
        let uri = 'mongodb://admin:ad12345@localhost:27017/gauth'
        let options = {
            connectTimeoutMS: 10000,// 10 giây
			useNewUrlParser: true,
			useCreateIndex: true,
        }
	//debugger;
        await mongoose.connect(uri, options)
        console.log('Connect Mongo Database successfully')

    } catch(error) {
        console.log(`Cannot connect Mongo. Error: ${error}`)
    }
}
connectDatabase()
module.exports = {
    mongoose
}
