/*
 * Created by @Khanh.
 * Sep15, 2019.
 */
const {mongoose} = require('../database')

var events = require('events');

const bcrypt = require('bcrypt')
const {sendEmail} = require('../../helpers/utility')
const jwt = require('jsonwebtoken')//Mã hoá 1 jsonObject thành token(string)
const secretString = "lkjldsfJHIWURsddfjhjllOIOImmnnbUIIUYkjhjawqwe"//tự cho 1 string tuỳ ý
const {Schema} = mongoose
const UserSchema = new Schema({
    //schema: cấu trúc của 1 collection 
    name: {type: String, default: 'unknown', unique: true},    
    email: {type: String, match:/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/, unique: true},
    password: {type: String, required: true},    
    active: {type: Number, default: 1}, //inactive  
    credit: {type: Number, default: 300},
	datecreated: {type: String, required: true}
})
const RuleSchema = new Schema({
    email: {type: String, match:/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/, unique: true},
    rule: {type: Number, default: 1},
	datecreated: {type: String, required: true}
})
const ExpireSchema = new Schema({
    token: {type: String, unique: true, required: true}
})
const CampSchema = new Schema({
	_id: {type: String, required: true, unique: true},
    name: {type: String, required: true},
	img: {type: String, default: 'No Data'},	
    owner: {type: String, match:/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/, required: true},
	milestone: {type: String, default: 'No Data', required: true},
	target: {type: String, default: 'No Data'},
    stat: {type: Number, default: 0},    
    credit: {type: Number, default: 300}, 
	rate: {type: String, default: '0.0'},
	datecreated: {type: String, required: true}
})
const SeedSchema = new Schema({
    campid: {type: String, required: true},
	seeddata: {type: String, default: 'No Data', required: true},	
    owner: {type: String, match:/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/, required: true},
	datecreated: {type: String, required: true}
})

//Chuyển từ Schema sang Model
const User = mongoose.model('User', UserSchema)
const Rule = mongoose.model('Rule', RuleSchema)
const Camp = mongoose.model('Camp', CampSchema)
const Expr = mongoose.model('Expr', ExpireSchema)
const Seed = mongoose.model('Seed', SeedSchema)

//create admin
const createadmin =  async () => {
    let rulevar = await Rule.findOne({ email : "a@1.com" })
                                               .exec();
	if (!rulevar){
            const encryptedPassword = await bcrypt.hash("1", 10)//saltRounds = 10
            const newUser = new User()
            newUser.name = "a1"
            newUser.email = "a@1.com"
            newUser.active = 1
            newUser.datecreated = new Date();
            newUser.password = encryptedPassword
            //debugger;
            await newUser.save()
    //set rule admin
    //set rule
            let findid = await checkid("a@1.com")
            const newRule = new Rule()
            newRule._id = findid
            newRule.email = "a@1.com"
            newRule.rule = 1
            newRule.datecreated = new Date();
            await newRule.save()
    }    
}
createadmin();

//send charity check
//at 8 oclock run check to all camp
var schedule = require('node-schedule');
var j = schedule.scheduleJob('0 0 8 * *', function(){
    const cronCreditJob = async () => {    
        
        //get all camps
        let campall = await viewAllCamp();
        var campobject = {};
        for(var i=0; i< campall.count; i++){
           campobject = campall.camps[i]
           
           var today = new Date(y,m,d);
           var campdate = new Date(campobject.milestone);
           console.log(campobject.name);
           console.log(today);
           console.log(campdate);
           //if milestone date equals to today
           if(campdate == today){
               
                //make transation 
                //with camp IN funding 
                if (campobject.stat != 1){
                //check milestone    
                        let currentRec = await User.findOne({ email : campobject.target });
                        
                        let updateReccredit = (Number(currentRec.credit) + Number(campobject.credit));
                        //update credit
                        const filterRec = { email : campobject.target };
                        const filterSender = { email : campobject.owner };
                        const updateRec = { credit: updateReccredit};
                        const updateSender = { credit: 0};
                        await Camp.findOneAndUpdate(filterSender, updateSender , {new: true})
                        await User.findOneAndUpdate(filterRec, updateRec , {new: true})
                        await tofabricchain(campobject.credit, currentcamp.owner, campobject.target )
                        //let logchain = await getfabricchainlog();
                }
            }    
        };
    };    
    cronCreditJob();    
});



//save history
const saveSeed = async (seeddata, campid, tokenkey) => {
    try {
        let validatetoken = await verifyJWT(tokenkey)
		let checkrulenow = await checkrule(tokenkey)
		let emailuser = await getToktoEmail(tokenkey)
		let findtok = await checkTokExp(tokenkey)	
		let findcampid = await checkCamp(campid)		
		if(findtok){
			if (checkrulenow) {
        	    if(validatetoken){
					if(findcampid){
					if(emailuser){					
							const newSeed = new Seed()
							newSeed.campid = campid
							newSeed.seeddata = seeddata
							newSeed.owner = emailuser
							newSeed.datecreated = new Date();
							await newSeed.save()
							return "OK!"
					}else{//validate token
						throw "ID user not found!"
					}	
					}else{//validate campid
						throw "Camp is not existed!"
					}					
         	    }else{//validate token
					throw "Invalid token!"
				}
       		}else{ //check rule
         	   throw "You have no right to do this action!"
     		}
		}else{ //check expired token
		   throw "Token has expired!"
		}
    } catch(error) {
        throw  error
    }
}
//view history by uid
const getSeeduid = async (tokenkey) => {
    try {
        let validatetoken = await verifyJWT(tokenkey)
		let checkrulenow = await checkrule(tokenkey)
		let emailuser = await getToktoEmail(tokenkey)
		let findtok = await checkTokExp(tokenkey)		
		if(findtok){
			if (checkrulenow) {
        	    if(validatetoken){
					if(emailuser){					
						const filter = { owner : emailuser };
						let allcamps = await Seed.find(filter);
						let countcamps = await Seed.count(filter);
						var campMap = [];
						allcamps.forEach((campvar) => {
							campMap.push({
								sid:campvar._id, 
								campid:campvar.campid, 
								seeddata: campvar.seeddata,				
								datecreated:campvar.datecreated
							})
						});
						return {count: countcamps,camps: campMap}
					}else{//validate token
						throw "ID user not found!"
					}						
         	    }else{//validate token
					throw "Invalid token!"
				}
       		}else{ //check rule
         	   throw "You have no right to do this action!"
     		}
		}else{ //check expired token
		   throw "Token has expired!"
		}
    } catch(error) {
        throw  error
    }
}
//get email from tok
const getToktoEmail = async (tokenkey) => {
    try {
        let decodedJson = await jwt.verify(tokenkey, secretString)
        if(Date.now() / 1000 >  decodedJson.exp) {
			return false
		}
		else{
			let foundUser = await User.findById(decodedJson.id)
			if (!foundUser) {
				return false
			}
			else{
				return foundUser.email	
			}
		}
		return false
    }catch(error) {
		return false
    }
   return false

}
//view history by camp
const getSeedcamp = async (campid) => {
    try {
		const filter = { campid : campid };
		let allcamps = await Seed.find(filter);
		let countcamps = await Seed.count(filter);
		var campMap = [];
		allcamps.forEach((campvar) => {
			campMap.push({
				sid:campvar._id, 
				seeddata: campvar.seeddata, 
				owner: campvar.owner,
				datecreated:campvar.datecreated
			})
		});

		return {count: countcamps,camps: campMap}	
    } catch(error) {
        throw  error
    }
}

const axios = require('axios')
const tofabricchain = async (creditdonate, emailfrom, emailto) => {
    let time = new Date();
    //generate hash
	var charset = "abcdefghijklmnopqrstuvwxyz0123456789";
	var texthash = '';
	for(i=0; i < charset.length; i++ )
			texthash += charset.charAt(Math.floor(Math.random() * charset.length));


    axios.post('http://54.255.244.180:4000/api/giveth.credithistory?access_token=83wSWhne6oox3Z31p3NvS26caXNOuL2WbtLFBg5I9QBDNgTZF8IFXB2e0AuQJysG', {
    '$class': 'giveth.credithistory',
    credithisid: texthash,
    credit: creditdonate,
    fromuser: emailfrom,
    touser: emailto,
    time: time 
    })
    .then((res) => {
    //console.log(`statusCode: ${res.statusCode}`)
        //console.log(res)
    })
    .catch((error) => {
        console.error(error)
    })
    
}
var logchain = '';
const getfabricchainlog = async () => {
    await axios.get('http://54.255.244.180:4000/api/system/historian?access_token=83wSWhne6oox3Z31p3NvS26caXNOuL2WbtLFBg5I9QBDNgTZF8IFXB2e0AuQJysG#!/giveth95credithistory/giveth_credithistory_find')
    .then((res) => {
        //console.log(res)
        //logchain = res;
		/*
		var eventEmitter = new events.EventEmitter();
		var myEventHandler = function () {
		  //console.log(rep);
		}
		eventEmitter.on('broadcast', myEventHandler)
		eventEmitter.emit('broadcast');
		*/
		//console.log(res);
		let rescount = res.data;
        return rescount
    })
    .catch((error) => {
        console.error(error)
    })
    
}

//donate credit
const donateCredit = async (email, campid, creditdonate, tokenkey) => {
    try {
	//validate session, token, user
        let validatetoken = await verifyJWT(tokenkey)
		let checkrulenow = await checkrule(tokenkey)
		let findtok = await checkTokExp(tokenkey)
		let findcampid = await checkCamp(campid)
		if(findtok){
			if (checkrulenow) {
        	    if(validatetoken){
					if(findcampid) {
						//donate
						//find credit
						let currentcamp = await Camp.findById(campid);
                        let currentuser = await User.findOne({ email : email })
                                                    .exec();
						//calculate rate
						if(currentcamp){
							//console.log(creditdonate)
							//console.log(currentuser.owner)
							let updatecredit = (Number(currentcamp.credit) + Number(creditdonate));
                            let updateUsercredit = (Number(currentuser.credit) - Number(creditdonate));
							//update rate
							const filter = { _id : campid };
                            const filtersender = { email : email };
							const update = { credit: updatecredit};
                            const updateUser = { credit: updateUsercredit};
                            await User.findOneAndUpdate(filtersender, updateUser , {new: true})
							await Camp.findOneAndUpdate(filter, update , {new: true})
                            await tofabricchain(creditdonate, email, currentcamp.name)
                            //logchain = await getfabricchainlog();
                            //console.log(logchain)
                            //return "IO Sock cal...";
						}
							
						
					}else { //find camp
						throw "Camp is not existed!"
					}					
         	    }else{//validate token
					throw "Invalid token!"
				}
       		}else{ //check rule
         	   throw "You have no right to do this action!"
     		}
		}else{ //check expired token
		   throw "Token has expired!"
		}
    } catch(error) {
        throw  error
    }
}

//rate credit
const rateCredit = async (campid, creditrate, tokenkey) => {
    try {
	//validate session, token, user
        let validatetoken = await verifyJWT(tokenkey)
		let checkrulenow = await checkrule(tokenkey)
		let findtok = await checkTokExp(tokenkey)
		let findcampid = await checkCamp(campid)
		if(findtok){
			if (checkrulenow) {
        	    if(validatetoken){
					if(findcampid) {
						//rate
						//find rate
						let currentcamp = await Camp.findById(campid);
						//calculate rate
						if(currentcamp){
							let updaterate = ((parseFloat(currentcamp.rate) + parseFloat(creditrate))/2).toString();
							//update rate
							const filter = { _id : campid };
							const update = { rate: updaterate};
							await Camp.findOneAndUpdate(filter, update , {new: true})
						}
		
						return "OK!"
					}else { //find camp
						throw "Camp is not existed!"
					}					
         	    }else{//validate token
					throw "Invalid token!"
				}
       		}else{ //check rule
         	   throw "You have no right to do this action!"
     		}
		}else{ //check expired token
		   throw "Token has expired!"
		}
    } catch(error) {
        throw  error
    }
}
//view users
const viewAllUser = async () => {
    try {
		var rulevar;
		let allusers = await User.find({});
		let countusers = await User.count();
		var userMap = [];
		var rule = 'normal user';
		var name = '';
		var uid = '';
        var credit = 0;
		for (const uservar of allusers) {
			rule = 'normal user'
			uid = uservar._id
			credit = uservar.credit
			rulevar = await Rule.findById(uservar._id)
			name = uservar.email
			if (rulevar){
				if(rulevar.rule == 1)
					rule = 'admin'
				else if (rulevar.rule == 2)
					rule = 'MOD'
			}
			userMap.push({uid, name, rule, credit})
		}

		return {count: countusers, users: userMap}
    } catch(error) {
        throw  error
    }
}

//view camps
const viewAllCamp = async () => {
    try {
		let allcamps = await Camp.find({});
		let countcamps = await Camp.count();
		var campMap = [];
		allcamps.forEach((campvar) => {
			campMap.push({cid:campvar._id, name:campvar.name, owner: campvar.owner, img: campvar.img, milestone: campvar.milestone,credit: campvar.credit,rate:campvar.rate, target:campvar.target,datecreated:campvar.datecreated,stat:campvar.stat})
		});

		return {count: countcamps,camps: campMap}	
    } catch(error) {
        throw  error
    }
}

//insert expired token
var insertExptoken= async (tokenkey) => {
    try {
        const expToken = new Expr()
        expToken.token = tokenkey
        await expToken.save()
        return "OK!"
        
    } catch(error) {        
        throw error       
    }
}
//insert new user
const insertUser = async (name, email, password) => {
    try {
    	//Mã hoá password trước khi lưu vào DB
		const encryptedPassword = await bcrypt.hash(password, 10)//saltRounds = 10
        const newUser = new User()
        newUser.name = name
        newUser.email = email
		newUser.active = 1
		newUser.datecreated = new Date();
        newUser.password = encryptedPassword
		//debugger;
        await newUser.save()
       // await sendEmail(email, encryptedPassword)
    } catch(error) {
        //Tự tuỳ chỉnh lại Error
        if (error.code === 11000) {
        	throw "Name or email doublicated!"
        }
        //throw error
    }
}
//view camp
const deleteUser = async (emailuser, tokenkey) => {
    try {
	//validate session, token, user
        let validatetoken = await verifyJWT(tokenkey)
		let checkrulenow = await checkrule(tokenkey)
		let userid = await checkid(emailuser)
		let finduser = await checkUser(emailuser)
		let findAdminuser = await checkAdmin(emailuser)
		
		let findtok = await checkTokExp(tokenkey)
		if(findtok){
			if (checkrulenow == 1) {
        	    if(validatetoken){
					if(finduser) {
						if(findAdminuser) {
							//delete user
							const filter = { _id : userid };
							const emailfilter = { email : emailuser };
							await User.deleteOne(filter)
							await Rule.deleteOne(emailfilter)
							return "OK!"	
						}else { //find user
							throw "Admin user can not be deleted!"
						}						
					}else { //find user
						throw "User is not existed!"
					}
         	    }else{//validate token
	           	throw "Invalid token!"
				}
       		}else{ //check rule
         	   throw "You have no right to do this action!"
     		}
		}else{ //check expired token
		   throw "Token has expired!"
		}
    } catch(error) {
        throw  error
    }
}
//check admin existed
var checkAdmin = async (email) => {
    try {
        let foundUser = await User.findOne({email: email.trim()})
                                .exec()
        if (!foundUser) {
            throw "User not found!"

        } else {
			let foundRuleAdmin = await Rule.findOne({email: foundUser.email})
									.exec()
			if(foundRuleAdmin){
				if(foundRuleAdmin.rule == 1)
					return false
				else
					return true
			}
			else
				return true
        }
    } catch(error) {        
        throw error       
    }
}
//Hàm activeUser dùng 1 GET request
//VD:
//http://Nguyens-iMac:3000/users/activateUser?secretKey=$2b$10$U4iDuK4aJ0.QSvVfRy8g/uvmSCUB0B8KfX75uUj8qr3xudHXcDG7y&email=nodejst9@gmail.com

//insert camp
const insertCamp = async (email, img, name, milestone, target, tokenkey) => {
    try {
	//validate session, token, user
        let validatetoken = await verifyJWT(tokenkey)
        let finduser = await checkUser(email)
		let checkrulenow = await checkrule(tokenkey)
		let findtok = await checkTokExp(tokenkey)
		let findtokenwithemail = await verifyTokEmail(tokenkey, email)
		if(findtok){
			if ((checkrulenow == 1) || (checkrulenow == 2)) {
        	    if(validatetoken){
					if(finduser) {
						if(findtokenwithemail) {
							//generate hash
							var charset = "abcdefghijklmnopqrstuvwxyz0123456789";
							var texthash = '';
							for(i=0; i < charset.length; i++ )
									texthash += charset.charAt(Math.floor(Math.random() * charset.length));
							//insert new camp)
							const newCamp = new Camp()
							newCamp._id = texthash
							newCamp.name = name
							newCamp.img = img
							newCamp.owner = email
							newCamp.milestone = milestone
							newCamp.target = target
							newCamp.datecreated = new Date();
							await newCamp.save()
							const rep = "OK!"
							const campid = texthash
							return {rep,campid}
						}else { //find token with email
							throw "This user is not current token's owner!"
						}
					}else { //find user
						throw "User is not existed!"
					}	   
         	    }else{//validate token
	           	throw "Invalid token!"
				}
       		}else{ //check rule
         	   throw "You have no right to do this action!"
     		}
		}else{ //check expired token
		   throw "Token has expired!"
		}
    } catch(error) {
        throw  error
    }
}
//view camp
const deleteCamp = async (campid, tokenkey) => {
    try {
	//validate session, token, user
        let validatetoken = await verifyJWT(tokenkey)
		let checkrulenow = await checkrule(tokenkey)
		let findcampid = await checkCamp(campid)
		let findtokenwithcamp = await verifyTokCamp(tokenkey, campid)
		
		let findtok = await checkTokExp(tokenkey)
		if(findtok){
			if ((checkrulenow == 1) || (checkrulenow == 2)) {
        	    if(validatetoken){
					if(findcampid) {
						if(findtokenwithcamp) {
							//delete camp
							const filter = { _id : campid };
							await Camp.deleteOne(filter)
							return "OK!"
						}else { //find token with camp
							throw "This token is not with current user or camp!"
						}					
					}else { //find camp
						throw "Camp is not existed!"
					}
         	    }else{//validate token
	           	throw "Invalid token!"
				}
       		}else{ //check rule
         	   throw "You have no right to do this action!"
     		}
		}else{ //check expired token
		   throw "Token has expired!"
		}
    } catch(error) {
        throw  error
    }
}

//edit current camp
const editCamp = async (campid, img, name, milestone, target, tokenkey) => {
    try {
	//validate session, token, user
        let validatetoken = await verifyJWT(tokenkey)
        //let finduser = await checkUser(email)
		let findcampid = await checkCamp(campid)
		//let findcampidwithemail = await checkCampWithUser(campid, email)
		//let findtokenwithemail = await verifyTokEmail(tokenkey, email)
		let findtokenwithcamp = await verifyTokCamp(tokenkey, campid)
		let checkrulenow = await checkrule(tokenkey)
		let findtok = await checkTokExp(tokenkey)
		if(findtok){
			if ((checkrulenow == 1) || (checkrulenow == 2)) {
        	    if(validatetoken){
					//if(finduser) {
						if(findcampid) {
							//if(findcampidwithemail) {
								//if(findtokenwithemail) {
									if(findtokenwithcamp) {
										//edit current camp
										if((name.trim() != "") && (milestone.trim() != "")&& (img.trim() != "")&& (target.trim() != "")){
											const filter = { _id : campid };
											const update = { name: name, img : img , milestone: milestone, target: target};
											await Camp.findOneAndUpdate(filter, update , {new: true})
											return "OK!"
										}else { //find token with camp
											throw "Camp's name, milestone should not be blank!"
										}
									}else { //find token with camp
										throw "This token is not with current user or camp!"
									}
								//}else { //find token with email
								//	throw "This user is not with current token's owner!"
								//}
							//}else { //find camp with email
								//throw "This user is not with current camp's owner!"
							//}
						}else { //find camp
							throw "Camp is not existed!"
						}
					//}else { //find user
						//throw "User is not existed!"
					//}	   
         	    }else{//validate token
	           	throw "Invalid token!"
				}
       		}else{ //check rule
         	   throw "You have no right to do this action!"
     		}
		}else{ //check expired token
		   throw "Token has expired!"
		}
    } catch(error) {
        throw  error
    }
}
//check current token with curren campid
const verifyTokCamp = async (tokenkey, campid) => {
    try {
        let decodedJson = await jwt.verify(tokenkey, secretString)
		let foundCamp = await Camp.findOne({_id: campid.trim()})
						.exec()
        if(Date.now() / 1000 >  decodedJson.exp) {
			return false
		}
		else{
			let foundUser = await User.findById(decodedJson.id)
			if (!foundUser) {
				return false
			}
			else if(!foundCamp){
				return false	
			}
			else{
				if(foundUser.email == foundCamp.owner) 
					return true
				else{
					let checkrulenow = await checkrule(tokenkey)
					if(checkrulenow == 1)
						return true
					else	
						return false	
				}	
			}
		}
		return false
    }catch(error) {
		return false
    }
   return false

}
//check current token with curren email
const verifyTokEmail = async (tokenkey, email) => {
    try {
        let decodedJson = await jwt.verify(tokenkey, secretString)
        if(Date.now() / 1000 >  decodedJson.exp) {
	    return false
        }
	else{
          let foundUser = await User.findById(decodedJson.id)
          if (!foundUser) {
			return false
          }
		  else {
			if(foundUser.email == email) 
				return true
			else
				return false	
		  }
	}
	return false
    }catch(error) {
	return false
    }
   return false

}
//check camp existed
var checkCampWithUser= async (campid, email) => {
    try {
        let foundCamp = await Camp.findOne({_id: campid.trim()})
                                .exec()
        if (!foundCamp) {
            return false

        } else {
			if (foundCamp.owner == email) 
				return true
			else
				return false
        }
    } catch(error) {        
        throw error       
    }
}

//uninsert rule
const uninsertRule = async (email, tokenkey) => {
    try {
	//validate session, token, user
        let validatetoken = await verifyJWT(tokenkey)
        let finduser = await checkUser(email)
		let checkrulenow = await checkrule(tokenkey)
		let findtok = await checkTokExp(tokenkey)
		let findAdminuser = await checkAdmin(email)
		if(findtok){
			if (checkrulenow == 1) {
        	    if(validatetoken){
					if(finduser) {
						if(findAdminuser) {
							//UNset rule
							const filter = { email : email };
							await Rule.deleteOne(filter)
							return "User was ruled to be NORMAL one!"
						}else { //find user
							throw "Admin user can not be set/unset!"
						}
					}else { //find user
						throw "User is not existed!"
					}	   
         	    }else{//validate token
	           	throw "Invalid token!"
				}
       		}else{ //check rule
         	   throw "You have no right to do this action!"
     		}
		}else{ //check expired token
		   throw "Token has expired!"
		}
    } catch(error) {
        throw  error
    }
}
//insert rule
const insertRuleAdmin = async (email, tokenkey) => {
    try {
	//validate session, token, user
        //let validatetoken = await verifyJWT(tokenkey)
        let finduser = await checkUser(email)
					if(finduser) {
						//if(findAdminuser) {
							//set rule
							let findid = await checkid(email)
							const newRule = new Rule()
							newRule._id = findid
							newRule.email = email
							newRule.rule = 1
							newRule.datecreated = new Date();
							await newRule.save()
							return "User was ruled to be ADMIN!"
			
					}else { //find user
						throw "User is not existed!"
					}	   

    } catch(error) {
        throw  error
    }
}
//insert rule
const insertRule = async (email, tokenkey) => {
    try {
	//validate session, token, user
        let validatetoken = await verifyJWT(tokenkey)
        let finduser = await checkUser(email)
		let checkrulenow = await checkrule(tokenkey)
		let findtok = await checkTokExp(tokenkey)
		let findAdminuser = await checkAdmin(email)
		if(findtok){
			if (checkrulenow == 1) {
        	    if(validatetoken){
					if(finduser) {
						if(findAdminuser) {
							//set rule
							let findid = await checkid(email)
							const newRule = new Rule()
							newRule._id = findid
							newRule.email = email
							newRule.rule = 2
							newRule.datecreated = new Date();
							await newRule.save()
							return "User was ruled to be MOD!"
						}else { //find user
							throw "Admin user can not be set/unset!"
						}					
					}else { //find user
						throw "User is not existed!"
					}	   
         	    }else{//validate token
	           	throw "Invalid token!"
				}
       		}else{ //check rule
         	   throw "You have no right to do this action!"
     		}
		}else{ //check expired token
		   throw "Token has expired!"
		}
    } catch(error) {
        throw  error
    }
}
//check token expired
var checkTokExp= async (tokenkey) => {
    try {
        let foundTok = await Expr.findOne({token: tokenkey.trim()})
                                .exec()
        //console.log(foundTok.token)
		if (foundTok) {
            return false
        } else {
            return true
        }
    } catch(error) {        
        throw error       
    }
}

//check camp existed
var checkCamp= async (campid) => {
    try {
        let foundCamp = await Camp.findOne({_id: campid.trim()})
                                .exec()
        if (!foundCamp) {
            return false

        } else {
            return true
        }
    } catch(error) {        
        throw error       
    }
}
//check user existed
var checkUser = async (email) => {
    try {
        let foundUser = await User.findOne({email: email.trim()})
                                .exec()
        if (!foundUser) {
            throw "User not found!"

        } else {
            return true
        }
    } catch(error) {        
        throw error       
    }
}
//get current id
var checkid = async (email) => {
    try {
        let foundUser = await User.findOne({email: email.trim()})
	  if (foundUser._id){
			return foundUser._id
	  }else{
	     return false
	  }
    } catch(error) {
        throw error
    }
}
//get current rule
var checkrule = async (tokenkey) => {
    try {
        let decodedJson = await jwt.verify(tokenkey, secretString)
        if(Date.now() / 1000 >  decodedJson.exp) {
            return false
        }
        else{
          let foundUser = await User.findById(decodedJson.id)
		  if (foundUser._id){
				 //console.log(foundUser._id)

				 let foundkey = await checkDBrule(foundUser._id)
					if (foundkey)
							return foundkey
					else
							return "0"
		  }else{
			 return false
		  }
		}
    } catch(error) {
        throw error
    }
}

//get current DB rule
var checkDBrule = async (key) => {
    try {
        let foundUser = await Rule.findById(key)
		//console.log(key)
		if (foundUser)
				return foundUser.rule
		else
				return "0"
        //});

    } catch(error) {
        throw error
    }
}

//active user
/*
const activateUser = async (email, secretKey) => {
    try {
        let foundUser = await User.findOne({email, password: secretKey})
                                .exec()
        if (!foundUser) {
            throw "User not found!"
        }    
        if (foundUser.active === 0) {
            foundUser.active = 1
            await foundUser.save()            
        } else {
            throw "User was activated!"//foundUser.active = 1
        }
    } catch(error) {        
        throw error       
    }
}
*/
//login
const loginUser = async (email, password) => {
    try {
        let foundUser = await User.findOne({email: email.trim()})
                            .exec()
//        debugger;
	if(!foundUser) {
            throw "User is not existed!"
        }
       // if(foundUser.active === 0) {
       //     throw "User chưa kích hoạt, bạn phải mở mail kích hoạt trước"               
       // }
		let encryptedPassword = foundUser.password
		let currentcredit = foundUser.credit
        let checkPassword = await bcrypt.compare(password, encryptedPassword)
		//await foundUser.compare(password, foundUser.password) // 
        //if (foundUser.password === password) {
		if (checkPassword) {
            //Đăng nhập thành công
            let jsonObject = {
                id: foundUser._id
            }
            const opts = {};
            opts.expiresIn = 14400;  //token expires in 2min
            const secret = "lkjldsfJHIWURsddfjhjllOIOImmnnbUIIUYkjhjawqwe"; //normally stored in process.env.secret
            //const token = await jwt.sign({ email }, secret, opts);	 
			
			//get current rule
            let tokenKey = await jwt.sign(jsonObject, secret, opts);
			let currentrule = await checkrule(tokenKey)

		return {tokenKey,currentrule, currentcredit};
        }
	else
	{
		throw "Wrong password!"
	}
    } catch(error) {
        throw error
    }
}

//check current token
const verifyJWT = async (tokenkey) => {
    try {
        let decodedJson = await jwt.verify(tokenkey, secretString)
        if(Date.now() / 1000 >  decodedJson.exp) {
	    return false
        }
	else{
          let foundUser = await User.findById(decodedJson.id)
          if (!foundUser) {
	    return false
          }
	  else {
	     return true
	  }
	}
	return false
    }catch(error) {
	return false
    }
   return false

}
module.exports = {User, insertUser, loginUser, verifyJWT, insertRule, uninsertRule, editCamp, insertCamp, insertExptoken, deleteCamp, deleteUser,viewAllCamp, viewAllUser, donateCredit, rateCredit, saveSeed,
	getSeeduid,
	getSeedcamp,
    insertRuleAdmin,
	getfabricchainlog
}
