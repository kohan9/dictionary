/*
 * Created by @Khanh.
 * Sep15, 2019.
 */
const nodemailer = require('nodemailer')
const PORT = 8076
const sendEmail = async (receiverEmail, secretKey) => {	    
    try {
        let transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: "abc@xyz", 
                pass: "abc@12"
            }
        })
        let mailOptions = {
            from: '"ABC Admin" <abc@xyz.com>', //Email người gửi
            to: receiverEmail, 
            subject: '[ABC] Tham gia XYZ.',         
            html: `
Dear ABC,

Mời bạn tham gia chương trình.

ABC team,
Admin.

		<h1>Click link below to activate:</h1>
                   http://${require('os').hostname()}:${PORT}/users/activateUser?secretKey=${secretKey}&email=${receiverEmail}
		<br><br>ABC Admin.` 
        }
        let info = await transporter.sendMail(mailOptions)
        console.log('Message sent: %s', info.messageId);
    } catch(error) {
        throw error
    }
}
module.exports = {
    sendEmail, 
    PORT   
}
