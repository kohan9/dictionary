/*
 * Created by @Khanh.
 * Sep15, 2019.
 */
const express = require('express');
const router = express.Router();
const jwt = require("jsonwebtoken");
const {
	insertUser,
	activateUser,
	verifyJWT,
	loginUser ,
	insertRule,
	editCamp,
	insertCamp,
	insertExptoken,
	deleteCamp,
	deleteUser,
	viewAllCamp,
	viewAllUser,
	donateCredit,
	rateCredit,
	uninsertRule,
	saveSeed,
	getSeeduid,
	getSeedcamp,
    insertRuleAdmin
} = require('../database/models/User')

var path    = require("path");
router.get('/',function(req,res){
  res.sendFile(path.join(__dirname+'/web/index.html'));
  //__dirname : It will resolve to your project folder.
});


module.exports = function(io) {

//api save history
router.post('/saveseed', async (req, res) =>{
        let {seeddata, campid, tokenkey} = req.body
	try {
			let rep = await saveSeed(seeddata, campid, tokenkey)
			res.json({
				result: '0',
				message: 'Save seeds done!',
				rep: rep
			})
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})
//api get history by user
router.post('/getseedbyuid', async (req, res) =>{
        let {tokenkey} = req.body
	try {
			let rep = await getSeeduid(tokenkey)
			res.json({
				result: '0',
				message: 'Get seeds done!',
				rep: rep
			})
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})
//api get history by campid
router.post('/getseedbycamp', async (req, res) =>{
    let {campid} = req.body
	try {
			let rep = await getSeedcamp(campid)
			res.json({
				result: '0',
				message: 'Get seeds done!',
				rep: rep
			})
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})
//getlog ether
router.post('/logether', async (req, res) =>{
	let {blockid} = req.body
	try {
		var rescount;
		
		await axios.post('http://54.255.244.180:8080/',{"jsonrpc":"2.0","method":"eth_getBlockByHash","params":[blockid, true],"id":1})
		.then((res1) => {
			rescount = res1.data;
			//io.on('connection',() => {
				//io.emit('broadcast', res1);
			//});
			res.json({
				result: '0',
				message: 'LC ETHER!',
				rep: rescount
			})
			//return rescount
		})
		.catch((error) => {
			console.error(error)
		})
	} catch(error) {
		res.json({
		result: '1',
		message: `${error}`
		})
    } 		
})
//get log chain
const axios = require('axios')
router.get('/logchain', async (req, res) =>{
	try {
		var rescount;
		await axios.get('http://54.255.244.180:4000/api/system/historian?access_token=83wSWhne6oox3Z31p3NvS26caXNOuL2WbtLFBg5I9QBDNgTZF8IFXB2e0AuQJysG#!/giveth95credithistory/giveth_credithistory_find')
		.then((res1) => {
			rescount = res1.data;
			//io.on('connection',() => {
				//io.emit('broadcast', res1);
			//});
			res.json({
				result: '0',
				message: 'LC!',
				rep: rescount
			})
			//return rescount
		})
		.catch((error) => {
			console.error(error)
		})
	} catch(error) {
		res.json({
		result: '1',
		message: `${error}`
		})
    } 		
})
const getfabricchainlog = async () => {
    await axios.get('http://54.255.244.180:4000/api/system/historian?access_token=83wSWhne6oox3Z31p3NvS26caXNOuL2WbtLFBg5I9QBDNgTZF8IFXB2e0AuQJysG#!/giveth95credithistory/giveth_credithistory_find')
    .then((res) => {
        //console.log(res)
        //logchain = res;
		/*
		var eventEmitter = new events.EventEmitter();
		var myEventHandler = function () {
		  //console.log(rep);
		}
		eventEmitter.on('broadcast', myEventHandler)
		eventEmitter.emit('broadcast');
		*/
		//console.log(res);
		let rescount = res.data;
        return rescount
    })
    .catch((error) => {
        console.error(error)
    })
    
}
//api donate
router.post('/donate', async (req, res) =>{
        let {email, campid, creditdonate, tokenkey} = req.body
	try {
			let rep = await donateCredit(email, campid, creditdonate, tokenkey)
			let logchain = await getfabricchainlog()
			console.log(logchain);
			io.on('connection',() => {
				io.emit('broadcast', logchain);
			});
			res.json({
				result: '0',
				message: 'Thank you for donation!',
				rep: logchain
			})
			
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})
//api rate
router.post('/rate', async (req, res) =>{
        let {campid, creditrate, tokenkey} = req.body
	try {
			let rep = await rateCredit(campid, creditrate, tokenkey)
			res.json({
				result: '0',
				message: 'Thank you for rating!',
				rep: rep
			})
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})

//api view all users
router.get('/alluser', async (req, res) =>{
        let {} = req.body
	try {
			let rep = await viewAllUser()
			res.json({
				result: '0',
				message: 'All users!',
				rep: rep
			})
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})
//api view all camps
router.get('/allcamp', async (req, res) =>{
        let {} = req.body
	try {
			let rep = await viewAllCamp()
			res.json({
				result: '0',
				message: 'All camps!',
				rep: rep
			})
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})

//api register new user
router.post('/registerUser', async (req, res) =>{
	let {name, email, password} = req.body    
	function validateEmail(email) {
	  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	  return re.test(email);
	}
    try {
	//debugger;
       	if(validateEmail(email)){
	 await insertUser(name, email, password)
	  	res.json({
	  		result: '0',
	  		message: 'Registration successfully!'
	  	})		
	}
	else
	{throw 'Sai định dạng email!'}
	} catch(error) {
		res.json({
            result: '1',
            message: `Could not register user. ERR : ${error}`
        })
	}
})

//router để kích hoạt user
//VD:
//http://Nguyens-iMac:3000/users/activateUser?secretKey=$2b$10$U4iDuK4aJ0.QSvVfRy8g/uvmSCUB0B8KfX75uUj8qr3xudHXcDG7y&email=nodejst9@gmail.com
/*
router.get('/activateUser', async (req, res) =>{	
	let {email, secretKey} = req.query	
	try {
		await activateUser(email, secretKey)
		res.send(`<h1 style="color:MediumSeaGreen;">Kích hoạt User thành công</h1>`)
	} catch(error) {
		res.send(`<h1 style="color:Red;">Không kích hoạt được User, lỗi: ${error}</h1>`)
	}
})
*/

//api expire token to logout
router.post('/exptok', async (req, res) =>{
        let {tokenkey} = req.body
	try {
			let rep = await insertExptoken(tokenkey)
			res.json({
				result: '0',
				message: 'User has logged out!',
				rep: rep
			})
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})
//api insert new camp
router.post('/newCamp', async (req, res) =>{
        let {email, img, name, milestone, target, tokenkey} = req.body
	try {
			//console.log({email, img, name, milestone, tokenkey});
			let rep = await insertCamp(email, img, name, milestone, target, tokenkey)
			res.json({
				result: '0',
				message: 'New charity campange event was created!',
				rep: rep
			})
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})
//api delete user
router.post('/deleteUser', async (req, res) =>{
        let {emailuser,tokenkey} = req.body
	try {
			let rep = await deleteUser(emailuser,tokenkey)
			res.json({
				result: '0',
				message: 'User has been deleted!',
				rep: rep
			})
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})
//api delete current camp
router.post('/deleteCamp', async (req, res) =>{
        let {campid,tokenkey} = req.body
	try {
			let rep = await deleteCamp(campid,tokenkey)
			res.json({
				result: '0',
				message: 'Camp has been deleted!',
				rep: rep
			})
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})
//api edit current camp
router.post('/editCamp', async (req, res) =>{
        let {campid, img, name, milestone, target, tokenkey} = req.body
	try {
			let rep = await editCamp(campid, img, name, milestone, target, tokenkey)
			res.json({
				result: '0',
				message: 'Camp event has been updated!',
				rep: rep
			})
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})
//api insert new rule
router.post('/uninsertRule', async (req, res) =>{
        let {email, tokenkey} = req.body
	try {
                let rep = await uninsertRule(email, tokenkey)
                res.json({
                        result: '0',
                        message: 'MODERATOR is unset successfully!',
                        rep: rep
			})
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})
//api insert new rule
router.post('/insertRule', async (req, res) =>{
        let {email, tokenkey} = req.body
	try {
            //let rep = await insertRuleAdmin(email, tokenkey)    
            let rep = await insertRule(email, tokenkey)
                res.json({
                        result: '0',
                        message: 'Ruled to be MODERATOR successfully!',
                        rep: rep
			})
        } catch(error) {
            res.json({
            result: '1',
            message: `${error}`
        	})
        } 
})

//api login
router.post('/loginUser', async (req, res) =>{	
	let {email, password} = req.body
    try {
		let tokenKey = await loginUser(email, password)
		res.json({
			result: '0',
			message: 'Login successfully!',
			tokenKey
	  	})
	} catch(error) {
		res.json({
            result: '1',
            message: `Could not logging in. ERR : ${error}`
        })
	}
})

    return router;
}


//module.exports = router
