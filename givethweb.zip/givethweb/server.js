/*
 * Created by @Khanh.
 * Sep15, 2019.
 */
const express = require('express')
const app = express()
var path = require('path');

//Nhúng middleware body-parser vào Express
const bodyParser = require('body-parser')

//secure server by helmet: https://helmetjs.github.io/
var helmet = require('helmet')
//app.use(helmet())

//secure server from DDOS by rate limit: https://www.npmjs.com/package/express-rate-limit
const rateLimit = require("express-rate-limit");
const limiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
 message:
    "GIVETH said: there are too many accounts created from this IP, please try again after 15 min!"
});
//app.use(limiter);

//allow other sitea can query to GIVETH
var cors = require('cors');
app.use(cors());

app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())

//Tuỳ biến Router
app.use(express.static(__dirname + '/web'));
const server = require('http').createServer(app);

//apply socketio from blockchain
const io = require('socket.io')(server);
const usersRouter  = require('./routers/usersRouter')(io)
app.use('/api', usersRouter)
app.use(require("./routers/usersRouter")(io));

//start server
server.listen(8076);

