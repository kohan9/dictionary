/*
 * Created by @Khanh.
 * Sep15, 2019.
 */
var currenttoken = ""; 
var currentrule = "";
var currentUsername = "";
var currentUserCreditavail = "300";
var currentcampid = "";
var currentcreditrate = "";
var currentget = 0;
var currentpost = 0;
var currentstartseed = 0;
var currentseed = '';
var currentcampname = '';
var currentcredit = 0;
var currentcampstat = 'funding...';

function hideall(){
	$("#Uinfo").hide();
	$("#loginform").hide();
	$("#loginbtn").hide();
	$("#logoutbtn").hide();
	$("#Uinfo").hide();
	$("#controlcamp").hide();
	$("#controluser").hide();
	$("#editeventgroup").hide();
	$("#usereventgroup").hide();
	$("#userlist").hide();
	$("#historylist").hide();
	$("#commoneventgroup").hide();
	$("#allcamp").hide();
	$("#loadingx").hide();
	$("#mydonate").hide();
}

function loginview(){
	hideall();
	$("#loginform").show();
	$("#commoneventgroup").show();
	$("#pwd").val('');
}
function allcampview(){
	hideall();
	if(currentrule == "1"){
		$("#Uinfo").show();
		$("#logoutbtn").show();
		$("#mydonate").show();
		$("#commoneventgroup").show();
		$("#controlcamp").show();
		$("#controluser").show();
	}
	if(currentrule == "2"){
		$("#Uinfo").show();
		$("#logoutbtn").show();
		$("#mydonate").show();
		$("#commoneventgroup").show();		
		$("#controlcamp").show();
	}
	else{
		if(currenttoken == ""){
			$("#loginbtn").show();
			$("#allcamp").show();
			$("#commoneventgroup").show();	
		}
		else{
			$("#Uinfo").show();
			$("#logoutbtn").show();
			$("#mydonate").show();
			$("#allcamp").show();	
			$("#commoneventgroup").show();	;			
		}
	}
	$("#allcamp").show();
	currentget = 1;
	var url = "/api/allcamp";
	gethttp(url,{});
}

function logoutview(){
	//console.log(currenttoken);
	currenttoken = "";
	currentrule = "";
	hideall();
	$("#loginbtn").show();
	$("#commoneventgroup").show();
}
function userhistoryview(hisarray){
		//get history
	currentpost = 7;
	var jsonvar = `{"tokenkey": "`+ currenttoken +`"}`;
	var url = "/api/getseedbyuid";
	posthttp(url,jsonvar);
	
	hideall();
	if(currentrule == "1"){
		$("#Uinfo").show();
		$("#logoutbtn").show();
		$("#mydonate").show();
		$("#controlcamp").show();
		$("#controluser").show();
	}
	if(currentrule == "2"){
		$("#Uinfo").show();
		$("#logoutbtn").show();
		$("#mydonate").show();
		$("#controlcamp").show();
	}
	else
	{
		if(currenttoken == ""){
			$("#loginbtn").show();
		}
		else{
			$("#Uinfo").show();
			$("#logoutbtn").show();	
			$("#mydonate").show();			
		}
	}
	$("#allcamp").show();	
	$("#historylist").show();	
	
	$("#historylist").empty();
	var html_prehistoryvalue = 
	`		<div>
				<input type="search" class="form-control" id="eventsearch" placeholder="Search keyword">
			</div>
	`;
	$("#historylist").append(html_prehistoryvalue);

}	
function historyview(hisarray){
	//get history
	currentpost = 6;
	var jsonvar = `{"campid": "`+ currentcampid +`"}`;
	var url = "/api/getseedbycamp";
	posthttp(url,jsonvar);
	
	
	hideall();
	if(currentrule == "1"){
		$("#Uinfo").show();
		$("#logoutbtn").show();
		$("#mydonate").show();
		$("#controlcamp").show();
		$("#controluser").show();
	}
	if(currentrule == "2"){
		$("#Uinfo").show();
		$("#logoutbtn").show();
		$("#mydonate").show();
		$("#controlcamp").show();
	}
	else
	{
		if(currenttoken == ""){
			$("#loginbtn").show();
		}
		else{
			$("#Uinfo").show();
			$("#logoutbtn").show();	
			$("#mydonate").show();			
		}
	}
	$("#allcamp").show();	
	$("#historylist").show();	
	
	$("#historylist").empty();
	var html_prehistoryvalue = 
	`			<div id="` + hisarray[0] + `">
				<table>
				<tr>
				<h2>` + hisarray[1] + `</h2>
				</tr>
				<tr>
				<td>
				<div class="form-group">
				  
				  <img src="` + hisarray[2] + `" style="width: 200px"  class="img-thumbnail" alt="c1">
				</div>
				</td>
				<td>
				<div class="form-group">
				  <label>Owner: ` + hisarray[4] + `</label><br>
				  <label>Milestone: ` + hisarray[3] + `</label><br>
				  <label>$ Avail: ` + hisarray[5] + `</label><br>
				  <label>Rate: ` + hisarray[6] + `</label>
				</div>
				<input id="starrate" type="text" class="rating" name="` + hisarray[0] + `" data-size="sm" >
				<input type="search" style="width: 200px" class="form-control" id="creditvalue` + hisarray[0] + `" placeholder="20">
				<button id="donatebtn" name="` + hisarray[0] + "::" + hisarray[1] + `" class="btn btn-default">Donate</button>
				</td>
				</tr>
				</table>
				<br>
			</div>
			<div>
				<input type="search" class="form-control" id="eventsearch" placeholder="Search keyword">
			</div>
	`;
	$("#historylist").append(html_prehistoryvalue);

	
	var html_linkscript = 
		`<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-star-rating/4.0.6/css/star-rating.min.css" media="all" rel="stylesheet" type="text/css" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-star-rating/4.0.6/js/star-rating.min.js" type="text/javascript"></script>
		`;
		$("#historylist").append(html_linkscript);
		
		
	//click donate
	$(".btn").click(function(e){
		if(e.currentTarget.attributes.id.value == "donatebtn"){
			var currentcamparr = e.currentTarget.attributes.name.value.split("::");
			currentcampid = currentcamparr[0];
			currentcampname = currentcamparr[1];
			if(currenttoken != ""){
				//console.log(Number($("#creditvalue"+currentcampid).val()));
				if((Number($("#creditvalue"+currentcampid).val()) >= 5) && (Number($("#creditvalue"+currentcampid).val()) <= 100)) {
					var url = "/api/donate";
					var jsonvar =  `{"email\":\"` + currentUsername +`\","campid\":\"` + currentcampid +`\","creditdonate\":\"` + $("#creditvalue"+currentcampid).val() + `\",\n\t\"tokenkey\":\"` + currenttoken +`\"}`;
					currentpost = 3;
					currentstartseed = 1;
					currentseed = `camp id: ` + currentcampid +`,camp name: ` + currentcampname +`,$ donated: ` + $("#creditvalue"+ currentcampid).val() + `,from: ` + currentUsername;
                    
                    currentcredit = currentcredit - Number($("#creditvalue"+currentcampid).val());
                    $("#Ucredit").text("$ "+ currentcredit);
                    
                    //$("#Ucredit").text(currentcredit);
					posthttp(url, jsonvar);

				}
				else
					alert($("#creditvalue"+currentcampid).val() + "111DONATE: You should donate from $5 to $100!");
			}
			else{
				alert("DONATE: You should login/register to donate!");
			}
		}
	});
	//click rate
	$(".rating").on('rating:change', function(event, value, caption) {
		currentcampid = this.attributes.name.value;;
		if(currenttoken != ""){				
			currentcreditrate = value;
			var url = "/api/rate";
			var jsonvar =  `{"campid\":\"` + currentcampid +`\","creditrate\":\"` + currentcreditrate + `\",\n\t\"tokenkey\":\"` + currenttoken +`\"}`;
			currentpost = 2;
			posthttp(url, jsonvar);
		}
		else{
			alert("RATE: You should login/register to rate!");
		}
	});
}
function docontrolcamp(){
	hideall();
	$("#Uinfo").show();
	$("#logoutbtn").show();
	$("#mydonate").show();
	$("#usereventgroup").show();
	$("#allcamp").show();
	if(currentrule == "1"){
		$("#controlcamp").show();
		$("#controluser").show();
	}
	if(currentrule == "2"){
		$("#controlcamp").show();
	}
	currentget = 3;
	var url = "/api/allcamp";
	gethttp(url,{});
}
function docontroluser(){
	hideall();
	$("#Uinfo").show();
	$("#logoutbtn").show();
	$("#mydonate").show();
	$("#userlist").show();
	$("#allcamp").show();
	if(currentrule == "1"){
		$("#controlcamp").show();
		$("#controluser").show();
		currentget = 2;
		var url = "/api/alluser";
		gethttp(url,{});
	}
}
function dologin(){
	hideall();
	$("#Uinfo").show();
	$("#logoutbtn").show();
	$("#mydonate").show();
	$("#commoneventgroup").show();
	if(currentrule == "1"){
		$("#controlcamp").show();
		$("#controluser").show();
	}
	if(currentrule == "2"){
		$("#controlcamp").show();
	}	
	$("#allcamp").show();
}
function displayalluser(userarray){
	hideall();
	if(currentrule == "1"){
		$("#Uinfo").show();
		$("#logoutbtn").show();
		$("#mydonate").show();
		$("#controlcamp").show();
		$("#controluser").show();
		$("#allcamp").show();
		$("#userlist").show();
		if(currenttoken != ""){
			$("#userlist").empty();
			var html_preuservalue = 
			`<div>
				<input type="search" class="form-control" id="eventsearch" placeholder="Search keyword">
			</div>
			<br>`;
			$("#userlist").append(html_preuservalue);
			for (const uservar of userarray){
				var html_uservalue = 
				`	<div id="` + uservar.uid + `">
					<table>
					<tr>
						<p>--------------------------------------------------------------------------<br>
						  <button id="setadminbtn" type="Set Admin Selected" name="` + uservar.name + `" class="btn btn-default">Set MOD Selected</button>
			<button id="unsetadminbtn" type="Unset Admin Selected" name="` + uservar.name + `" class="btn btn-default">Unset MOD Selected</button>
			<button id="deleteuser" type="Delete Selected" name="` + uservar.name + `" class="btn btn-default">Delete Selected</button>
						  <br>
						  Owner: ` + uservar.name + `<br>
						  Role: ` + uservar.rule + `</p>
					</tr>
					</table>
					</div>
				`;
				$("#userlist").append(html_uservalue);
			};
			$(".btn").click(function(e){
			//set mod
			if(e.currentTarget.attributes.id.value == "setadminbtn"){
				var emailtoset = e.currentTarget.attributes.name.value;
				var url = "/api/insertRule";
				var jsonvar =  `{"email\":\"` + emailtoset +`\",\"tokenkey\":\"` + currenttoken +`\"}`;
				var answer = window.confirm("Are you sure to SET MOD this?")
				if (answer) {
					currentpost = 5;
					posthttp(url, jsonvar);
					
				}
			}
			//unset mod
			else if(e.currentTarget.attributes.id.value == "unsetadminbtn"){
				var emailtounset = e.currentTarget.attributes.name.value;
				var url = "/api/uninsertRule";
				var jsonvar =  `{"email\":\"` + emailtounset +`\",\"tokenkey\":\"` + currenttoken +`\"}`;
				var answer = window.confirm("Are you sure to UNSET this?")
				if (answer) {
					currentpost = 5;
					posthttp(url, jsonvar);
					
				}
			}
			//to delte user
			else if(e.currentTarget.attributes.id.value == "deleteuser"){
				var emailtodel = e.currentTarget.attributes.name.value;
				var url = "/api/deleteUser";
				var jsonvar =  `{"emailuser\":\"` + emailtodel +`\",\"tokenkey\":\"` + currenttoken +`\"}`;
				var answer = window.confirm("Are you sure to DELETE this?")
				if (answer) {
					currentpost = 5;
					posthttp(url, jsonvar);
					
				}
			}
		});
		}
		else
			alert("Invalid session!");
	}
	else
		alert("You have no right to do this action!");
}
function displayhistorycamp(camparray){
	//loop for to get value
	//console.log(camparray[0].);
	$("#historylist").show();
	for (const campvar of camparray){
		var html_historyvalue = 
		`			<div id="` + campvar.sid +`">
						<p>--------------------------------------------------------------------------<br>
						  time: ` + campvar.datecreated +`<br>
						  from: ` + campvar.owner +`<br>
						  seed: ` + campvar.seeddata +`<br>
					</div>
		`;
		$("#historylist").append(html_historyvalue);
	}
	//end loop for
}	
function displayhistoryuid(camparray){
	//console.log(camparray);
	//loop for to get value
	$("#historylist").show();
	for (const campvar of camparray){
		var html_historyvalue = 
		`			<div id="` + campvar.sid +`">
						<p>--------------------------------------------------------------------------<br>
						  time: ` + campvar.datecreated +`<br>
						  seed: ` + campvar.seeddata +`<br>
					</div>
		`;
		$("#historylist").append(html_historyvalue);
	}
	//end loop for
}
function displayusercamp(camparray){
	hideall();
	if((currentrule != "0") && (currenttoken != "")){
		$("#Uinfo").show();
		$("#logoutbtn").show();
		$("#mydonate").show();
		$("#allcamp").show();
		$("#controlcamp").show();
		$("#controluser").show();
		if(currentrule == "2")
			$("#controluser").hide();

		$("#usereventgroup").show();
		$("#usereventgroup").empty();
		var html_precampvalue = 
		`<div>
				<input type="search" class="form-control" id="eventsearch" placeholder="Search keyword"><br>
				<h4>Camps of ` + currentUsername + `</h4>
				<button id="newcamp" type="Manage Users" class="btn btn-default">New camp</button>
			</div>`;
		$("#usereventgroup").append(html_precampvalue);
		for (const campvar of camparray){
			//console.log(currentUsername);
			//console.log(campvar.owner);
            if(campvar.stat == 0)
                currentcampstat = `<font color="green">funding...</font>`;
            else
                currentcampstat = `<font color="red">funding done!!!</font>`;
            
			if(currentrule == "2"){
				if(currentUsername == campvar.owner){
					var html_campvalue = 
					`
					<div id="` + campvar.cid + `">
						<table>
							<tr>
								<h5>------------------------------------------------------------------------------------------------------------------------------------</h5>
								<h2>` + campvar.name + `</h2><h6> ` + currentcampstat + `</h6>
								<button id="editcamp" name="` + campvar.cid +"::"+ campvar.name +"::"+ campvar.img + "::"+ campvar.milestone +"::"+ campvar.target + `" type="Manage Users" class="btn btn-default">Edit camp</button>
								<button id="deletecamp" name="` + campvar.cid + `" type="Manage Users" class="btn btn-default">Delete camp</button>
							</tr>
							<tr>
								<td>
									<div class="form-group">
									  
									  <img src="` + campvar.img + `" style="width: 200px" class="img-thumbnail" alt="c1">
									</div>
								</td>
								<td>
									<div class="form-group">
									  <label>Milestone: ` + campvar.milestone + `</label><br>
									  <label>$ Avail: ` + campvar.credit + `</label><br>
									  <label>Rate: ` + campvar.rate + `</label>
									</div>
									<button id="hisdonbtn" name="` + campvar.cid +"::"+ campvar.name +"::"+ campvar.img + "::"+ campvar.milestone + "::" + campvar.owner + "::" + campvar.credit + "::" + campvar.rate + `" class="btn btn-default">History</button>
								</td>
							</tr>
						</table>
					</div>
					`;
					$("#usereventgroup").append(html_campvalue);
				}
			}
			else if(currentrule == "1"){
				var html_campvalue = 
				`
				<div id="` + campvar.cid + `">
					<table>
						<tr>
							<h5>------------------------------------------------------------------------------------------------------------------------------------</h5>
							<h2>` + campvar.name + `</h2> <h6> ` + currentcampstat + `</h6>
							<button id="editcamp" name="` + campvar.cid +"::"+ campvar.name +"::"+ campvar.img + "::"+ campvar.milestone+ "::"+ campvar.target + `" type="Manage Users" class="btn btn-default">Edit camp</button>
							<button id="deletecamp" name="` + campvar.cid + `" type="Manage Users" class="btn btn-default">Delete camp</button>
						</tr>
						<tr>
							<td>
								<div class="form-group">
								  
								  <img src="` + campvar.img + `" style="width: 200px" class="img-thumbnail" alt="c1">
								</div>
							</td>
							<td>
								<div class="form-group">
								  <label>Milestone: ` + campvar.milestone + `</label><br>
								  <label>$ Avail: ` + campvar.credit + `</label><br>
								  <label>Rate: ` + campvar.rate + `</label>
								</div>
								<button id="hisdonbtn" name="` + campvar.cid +"::"+ campvar.name +"::"+ campvar.img + "::"+ campvar.milestone + "::" + campvar.owner + "::" + campvar.credit + "::" + campvar.rate + `" class="btn btn-default">History</button>
							</td>
						</tr>
					</table>
				</div>
				`;
				$("#usereventgroup").append(html_campvalue);
			}
		};
		var detailcamp = [];
		//to edit camp
		$(".btn").click(function(e){
			if(e.currentTarget.attributes.id.value == "editcamp"){
				detailcamp = e.currentTarget.attributes.name.value.split("::");
				currentcampid = detailcamp[0];
				doeditcamp(detailcamp, 1);
			}
			//to view history
			else if(e.currentTarget.attributes.id.value == "hisdonbtn"){
				detailcamp = e.currentTarget.attributes.name.value.split("::");
				currentcampid = detailcamp[0];
				historyview(detailcamp);
			}
			//to delte camp
			else if(e.currentTarget.attributes.id.value == "deletecamp"){
				currentcampid = e.currentTarget.attributes.name.value;
				var url = "/api/deleteCamp";
				var jsonvar =  `{"campid\":\"` + currentcampid +`\",\"tokenkey\":\"` + currenttoken +`\"}`;
				var answer = window.confirm("Are you sure to DELETE this?")
				if (answer) {
					currentpost = 4;
					posthttp(url, jsonvar);
					
				}
			}
		});
		//to create new camp
		$("#newcamp").click(function(e){
			detailcamp = {};
			doeditcamp(detailcamp, 0);
		});
	};
}

function displayallcamp(camparray){
	hideall();
	if(currentrule == "1"){
		$("#Uinfo").show();
		$("#logoutbtn").show();
		$("#mydonate").show();
		$("#controlcamp").show();
		$("#controluser").show();
	}
	if(currentrule == "2"){
		$("#Uinfo").show();
		$("#logoutbtn").show();
		$("#mydonate").show();
		$("#controlcamp").show();
	}
	else{
		if(currenttoken == ""){
			$("#loginbtn").show();
		}
		else{
			$("#Uinfo").show();
			$("#logoutbtn").show();		
			$("#mydonate").show();			
		}
	}
	$("#allcamp").show();
	$("#commoneventgroup").show();
	$("#commoneventgroup").empty();
	var html_precampvalue = 
	`<div>
			<input type="search" class="form-control" id="eventsearch" placeholder="Search keyword">
		</div>`;
	$("#commoneventgroup").append(html_precampvalue);
	for (const campvar of camparray){
        if(campvar.stat == 0)
            currentcampstat = `<font color="green">funding...</font>`;
        else
            currentcampstat = `<font color="red">funding done!!!</font>`;
            
		var html_campvalue = 
		`<div id="event` + campvar.cid + `">
				<table>
					<tr>
						<h5>------------------------------------------------------------------------------------------------------------------------------------</h5>
						<h2>` + campvar.name + `</h2><h6> ` + currentcampstat + `</h6>
					</tr>
					<tr>
						<td>
							<div class="form-group">
							  
							  <img src="` + campvar.img + `" style="width: 200px" class="img-thumbnail" alt="c1">
							</div>
						</td>
						<td>
							<div class="form-group">
							  <label>Owner: ` + campvar.owner + `</label><br>
							  <label>Milestone: ` + campvar.milestone + `</label><br>
							  <label>$ Avail: ` + campvar.credit + `</label><br>
							  <label>Rate: ` + campvar.rate + `</label>
							</div>
							<input id="ratebtn` + campvar.cid + `" name="` + campvar.cid + `" type="number" class="rating" min=1 max=5 step=1 data-size="sm" ><br>
							<input type="search" style="width: 200px" class="form-control" id="creditvalue` + campvar.cid + `" placeholder="20">
							<button class="btn btn-default" name="` + campvar.cid +"::" + campvar.name +  `" id="donatebtn" >Donate</button>
							<button id="hisdonbtn" name="` + campvar.cid +"::"+ campvar.name +"::"+ campvar.img + "::"+ campvar.milestone + "::" + campvar.owner + "::" + campvar.credit + "::" + campvar.rate + `" class="btn btn-default">History</button>
						</td>
					</tr>
				</table>
			</div>
		`;
		var html_linkscript = 
		`<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-star-rating/4.0.6/css/star-rating.min.css" media="all" rel="stylesheet" type="text/css" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-star-rating/4.0.6/js/star-rating.min.js" type="text/javascript"></script>
		`;
		$("#commoneventgroup").append(html_campvalue);
		$("#commoneventgroup").append(html_linkscript);

	};
	//click donate
	$(".btn").click(function(e){
		if(e.currentTarget.attributes.id.value == "donatebtn"){
			var currentcamparr = e.currentTarget.attributes.name.value.split("::");
			currentcampid = currentcamparr[0];
			currentcampname = currentcamparr[1];
			if(currenttoken != ""){
				//console.log(Number($("#creditvalue"+currentcampid).val()));
				if((Number($("#creditvalue"+currentcampid).val()) >= 5) && (Number($("#creditvalue"+currentcampid).val()) <= 100)) {
					var url = "/api/donate";
					var jsonvar =  `{"email\":\"` + currentUsername +`\","campid\":\"` + currentcampid +`\","creditdonate\":\"` + $("#creditvalue"+ currentcampid).val() + `\",\n\t\"tokenkey\":\"` + currenttoken +`\"}`;
					currentpost = 3;
					currentstartseed = 1;
					currentseed = `camp id: ` + currentcampid +`,camp name: ` + currentcampname +`,$ donated: ` + $("#creditvalue"+ currentcampid).val() + `,from: ` + currentUsername;
                    
                    currentcredit = currentcredit - Number($("#creditvalue"+currentcampid).val());
                    $("#Ucredit").text("$ "+ currentcredit);
					posthttp(url, jsonvar);

				}
				else
					alert($("#creditvalue"+currentcampid).val() + "222DONATE: You should donate from $5 to $100!");
			}
			else{
				alert("DONATE: You should login/register to donate!");
			}
		}
		//click history
		else if(e.currentTarget.attributes.id.value == "hisdonbtn"){
			var detailcamp = e.currentTarget.attributes.name.value.split("::");
			currentcampid = detailcamp[0];
			historyview(detailcamp);
		}
	});
	//click rate
	$(".rating").on('rating:change', function(event, value, caption) {
		currentcampid = this.attributes.name.value;;
		if(currenttoken != ""){				
			currentcreditrate = value;
			var url = "/api/rate";
			var jsonvar =  `{"campid\":\"` + currentcampid +`\","creditrate\":\"` + currentcreditrate + `\",\n\t\"tokenkey\":\"` + currenttoken +`\"}`;
			currentpost = 2;
			posthttp(url, jsonvar);
		}
		else{
			alert("RATE: You should login/register to rate!");
		}
	});
}

function gethttphistory(url, dataget){
	$("#loadingx").show();
	
		var settings = {
		  "async": true,
		  "crossDomain": true,
		  "url": "http://192.168.1.4:8076/api/getseedbycamp",
		  "method": "GET",
		  "headers": {
			"Content-Type": "application/json",
			"Accept": "*/*",
			"cache-control": "no-cache"
		  },
		  "processData": false,
		  "data": "{\"campid\": \"gemt61cpayfixskodzg553bx57hzes2fnhs9\"}"
		}

		$.ajax(settings).done(function (response) {
		  console.log(JSON.stringify(response.rep));
		});
		/*
		if(response.result == "0"){
			//allcamp
			//all seed by camp
			if(currentget == 4){
				//console.log(dataget);
				console.log(JSON.stringify(response.rep));
				currentget = 0;
				displayhistorycamp(response.rep.camps);
				
			}
			//all seed by uid
			else if(currentget == 5){
				currentget = 0;
				displayhistoryuid(response.rep.camps);
			}
		}	
		else	
			alert(response.message);
	  
		});
		*/		
}
function gethttp(url, dataget){
	$("#loadingx").show();
	
	var settings = {
	  "async": true,
	  "crossDomain": true,
	  "url": url,
	  "method": "GET",
	  "headers": {
		"Content-Type": "application/json",
	  },
	  "data": dataget
	}
	$.ajax(settings).done(function (response) {
		$("#loadingx").hide();
		//console.log(JSON.stringify(response.rep));
		if(response.result == "0"){
			//allcamp
			if(currentget == 1){
				currentget = 0;
				displayallcamp(response.rep.camps);
			}
			//new user
			else if(currentget == 2){
				currentget = 0;
				displayalluser(response.rep.users);
			}
			//allusercamp
			else if(currentget == 3){
				currentget = 0;
				displayusercamp(response.rep.camps);
			}
			//all seed by camp
			else if(currentget == 4){
				//console.log(dataget);
				
				currentget = 0;
				displayhistorycamp(response.rep.camps);
				
			}
			//all seed by uid
			else if(currentget == 5){
				currentget = 0;
				displayhistoryuid(response.rep.camps);
			}
			else if(currentget == 6){
				currentget == 0;
				for(var i = 0; i < response.rep.length; i++){
					$('#output').append(JSON.stringify(response.rep[i]) + "<br><br>");
					
				}
			}
				
		}	
		else	
			alert(response.message);
	  
	});
	
}
function posthttp(url, jsonvar){
	$("#loadingx").show();
	var settings = {
	  "async": true,
	  "crossDomain": true,
	  "url": url,
	  "method": "POST",
	  "headers": {
		"Content-Type": "application/json",
	  },
	  "data": jsonvar
	}
	$.ajax(settings).done(function (response) {
		$("#loadingx").hide();
		if(response.result == "0"){
			//login
			if(response.tokenKey){
				$("#Uname").text(currentUsername);
				$("#Ucredit").text("$ "+ response.tokenKey.currentcredit);
                currentcredit = response.tokenKey.currentcredit;
				currenttoken = response.tokenKey.tokenKey;
				currentrule = response.tokenKey.currentrule;
				alert(response.message);
				dologin();
                //$("#Ucredit").text(currentcredit);
				
			}
			//registration
			else if(currentpost == 2){
				currentpost = 0;
				alert(response.message);
				//docontrolcamp();
			}
			//donate
			else if (currentpost == 3){
				currentpost = 0;
				if(currentstartseed == 1){
					currentstartseed = 0;
					var url = "/api/saveseed";
					var jsonvar =  `{"seeddata\":\"` + currentseed +`\","campid\":\"` + currentcampid + `\",\"tokenkey\":\"` + currenttoken +`\"}`;
					//console.log(jsonvar);
					currentpost = 2;
					posthttp(url, jsonvar);
				}
				alert(response.message);
				allcampview();
			}
			//edit, delete, create camp
			else if (currentpost == 4){
				currentpost = 0;
				alert(response.message);
				docontrolcamp();
			}
			//edit, set mod user
			else if (currentpost == 5){
				currentpost = 0;
				alert(response.message);
				docontroluser();
			}
			//seed
			else if (currentpost == 6){
				//console.log(response.rep.camps);
				displayhistorycamp(response.rep.camps);
			}
			//seed
			else if (currentpost == 7){
				//console.log(response.rep.camps);
				displayhistoryuid(response.rep.camps);
			}
			//alert(response.message);		
			else if (currentpost == 8){
				//console.log(response.rep.camps);
				$('#output2').append(JSON.stringify(response.rep) + "<br><br>");
			}			
		}	
		else{	
			alert(response.message);
		}
	});
	
}

function doeditcamp(camp, task){
	hideall();
	$("#Uinfo").show();
	$("#logoutbtn").show();
	$("#mydonate").show();
	$("#allcamp").show();
	if(currentrule == "1"){
		$("#controlcamp").show();
		$("#controluser").show();
	}
	if(currentrule == "2"){
		$("#controlcamp").show();
	}	
	$("#editeventgroup").show();
	if(currentrule != "0"){
		//edit camp
		if(task == 1){
			$("#campimg").val(camp[2]);
			//$("#campimg").prop('disabled', true);
			//$("#campimgchoose").value(camp[2]);
			$("#campname").val(camp[1]);
			$("#campmile").val(camp[3]);
			$("#camptarget").val(camp[4]);
			$("#savebtn").click(function(e){
				var url = "/api/editCamp";
				var jsonvar =  `{"campid\":\"` + currentcampid +`\",\"img\":\"` + $("#campimg").val() + `\",\"name\":\"` + $("#campname").val() + `\",\"milestone\":\"` + $("#campmile").val() + `\",\"target\":\"` + $("#camptarget").val() +`\",\"tokenkey\":\"` + currenttoken +`\"}`;
				currentpost = 4;
				posthttp(url, jsonvar);
			});
		}
		//create new camp
		else if(task == 0){
			$("#campimg").val('');
			$("#campname").val('');
			$("#campmile").val('');
			$("#camptarget").val('');
			$("#savebtn").click(function(e){
				//check empty
				if(($("#campname").val().trim() !="") && ($("#campimg").val().trim() !="")&& ($("#camptarget").val().trim() !="") &&($("#campmile").val().trim() !="")){
					//check date
					var date = $("#campmile").val();
					var varDate = new Date(date);
					var today = new Date();
					today.setHours(0,0,0,0);	
					if(varDate > today) {
						var campimgupdated = $("#campimg").val();
						//campimgupdated = campimgupdated.substring(12,campimgupdated.length);
						var url = "/api/newCamp";
						var jsonvar =  `{\"email\":\"` + currentUsername +`\",\"img\":\"` +campimgupdated + `\",\"name\":\"` + $("#campname").val() + `\",\"milestone\":\"` + $("#campmile").val() +`\",\"target\":\"` + $("#camptarget").val() + `\",\"tokenkey\":\"` + currenttoken +`\"}`;
						//console.log(jsonvar);
						currentpost = 4;
						posthttp(url, jsonvar);
					}
					else
						alert("Milestone date should be greater than today!")
				}
				else	
					alert("Data for new camp should not be blank!")
			});
		}
	}
}

$(document).ready(function () {
	//star rating
	//$("#starrate").rating();
	
	//view for guest
	allcampview();

	//view for user
	
	//click login  
	$("#loginbtn").click(function(e){
		loginview();
	});


	//click logout 
	$("#logoutbtn").click(function(e){
		var url = "/api/exptok";
		var jsonvar =  `{"tokenkey\":\"` + currenttoken + `\"}`;
		posthttp(url, jsonvar);
		logoutview();
	});
	
	//to login
	$("#tologin").click(function(e){
		currentUsername = $("#email").val();
		var url = "/api/loginUser";
		var jsonvar =  `{"email\":\"` + $("#email").val() + `\",\n\t\"password\":\"` + $("#pwd").val() +`\"\n}`;
		posthttp(url, jsonvar);
	});
	$('#pwd').keypress(function(e) {
		if (e.which == '13') {
			currentUsername = $("#email").val();
			var url = "/api/loginUser";
			var jsonvar =  `{"email\":\"` + $("#email").val() + `\",\n\t\"password\":\"` + $("#pwd").val() +`\"\n}`;
			posthttp(url, jsonvar);
		}
	});
	
	//to register
	$("#toregister").click(function(e){
		var url = "/api/registerUser";
		var jsonvar =  `{"name\":\"` + $("#name").val() +`\","email\":\"` + $("#email").val() + `\",\n\t\"password\":\"` + $("#pwd").val() +`\"\n}`;
		currentpost = 2;
		posthttp(url, jsonvar);
	});
	
	//click all camp
	$("#allcamp").click(function(e){
		allcampview();
	});
	
	//to manage camp
	$("#controlcamp").click(function(e){
		docontrolcamp();
	});
	
	
	//to manage user
	$("#controluser").click(function(e){
		docontroluser();
	});
	//view my donation
	$("#mydonate").click(function(e){
		userhistoryview();
	});

	var url = "/api/logchain";
	var jsonvar =  ``;
	currentget = 6;
	gethttp(url, jsonvar);
	
	var url = "/api/logether";
	var jsonvar =  `{"blockid\":\"0xc86818b9a81024650c0f8df5644822a5903b753db054820bf40d6ec7d62357d4\"}`;
	currentpost = 8;
	posthttp(url, jsonvar);
	//refresh chain log
	
	/*
	// Create WebSocket connection.
	//const socket = new WebSocket('ws://54.255.235.179:8076');
	var socket = io.connect('http://54.255.235.179:8076');

	// Listen for messages
	socket.on('broadcast', function (data) {
		console.log(data);
		if(data != null){
			//$('#output').empty();
			$('#output').text(data);
		}
	});
	*/
});
